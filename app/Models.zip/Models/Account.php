<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;


class Account extends Model
{
    use HasFactory;
    protected $fillable = ['user_id', 'bank_id', 'type', 'balance'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function bank()
    {
        return $this->belongsTo(Bank::class);
    }

    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function family()
    {
        return $this->belongsTo(Family::class);
    }

    protected static function booted()
    {
        static::addGlobalScope('family', function (Builder $builder) {
            if (auth()->check()) {
                $builder->where('family_id', auth()->user()->family_id);
            }
        });

        static::creating(function ($model) {
            $model->family_id ??= auth()->user()->family_id;
            $model->user_id = auth()->user()->id;
        });
    }

}
